#include "loginwindow.h"

LoginWindow::LoginWindow(QWidget *parent)
    : QWidget(parent)
{
    //����Ϊ�̶�����
    this->setMinimumWidth(320);
    this->setMaximumWidth(320);
    this->setMinimumHeight(180);
    this->setMaximumHeight(180);

    QIcon icon(":/icon/logo/sfit.png");
    setWindowIcon(icon);
    setWindowTitle(QStringLiteral("Welcome to SFIT toolkit"));

    pb_logoin =new QPushButton("Login", this);
    pb_close =new QPushButton("Exit", this);

    lb_name = new QLabel("Username ", this);
    lb_paswd =new QLabel("Passwd   ", this);
    le_name = new QLineEdit(this);
    le_passwd = new QLineEdit(this);
    remember = new QCheckBox("remember",this);
    passwd = new QCheckBox("showpass",this);

    lb_ipaddr = new QLabel("IPAddr   ", this);
    le_ipaddr = new QLineEdit(this);
    le_ipaddr->setPlaceholderText(QString("Example: 10.0.0.1:13001"));

    QHBoxLayout *hbox1 =new QHBoxLayout;
    QHBoxLayout *hbox2 =new QHBoxLayout;
    QHBoxLayout *hbox3 =new QHBoxLayout;
    QHBoxLayout *hbox4 =new QHBoxLayout;
    hbox1->addWidget(lb_name);
    hbox1->addWidget(le_name);
    hbox1->addWidget(remember);

    hbox2->addWidget(lb_paswd);
    hbox2->addWidget(le_passwd);
    hbox2->addWidget(passwd);

    hbox3->addWidget(pb_logoin);
    hbox3->addWidget(pb_close);

    hbox4->addWidget(lb_ipaddr);
    hbox4->addWidget(le_ipaddr);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox1);
    vbox->addLayout(hbox2);
    vbox->addLayout(hbox4);
    vbox->addLayout(hbox3);

    setLayout(vbox);

    le_passwd->setEchoMode(QLineEdit::Password);
    le_passwd->setMaxLength(16);

    m_socket = new QTcpSocket(this);

    //�����źŲ�
    connect(passwd, SIGNAL(toggled(bool)), this, SLOT(pswdMode()));
    connect(pb_close, &QPushButton::clicked, &QApplication::quit);
    connect(pb_logoin, &QPushButton::clicked, this, &LoginWindow::loginServer);
    connect(m_socket, &QTcpSocket::connected, this, &LoginWindow::connected);
}

LoginWindow::~LoginWindow()
{

}

void LoginWindow::pswdMode()
{
    if(passwd->isChecked()) {
        le_passwd->setEchoMode(QLineEdit::Normal);
    }else {
        le_passwd->setEchoMode(QLineEdit:: Password);
    }
}

void LoginWindow::loginServer()
{
    QString ipStr = le_ipaddr->text();
    QStringList list = ipStr.split(":");
    if (list.size() != 2) {
        QMessageBox::about(nullptr, "Error", "Please input the right ip address");
        return ;
    }
    QString ip(list[0]);
    quint16 port = list[1].toInt();

    m_socket->setProxy(QNetworkProxy::NoProxy);
    m_socket->connectToHost(list[0], port);
}

void LoginWindow::connected()
{
    qDebug()<<"connected to server"<<endl;
}




