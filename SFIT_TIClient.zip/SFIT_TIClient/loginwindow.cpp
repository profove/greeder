#include "loginwindow.h"

LoginWindow::LoginWindow(QWidget *parent)
    : QWidget(parent)
{
    this->setMinimumWidth(300);
    this->setMaximumWidth(300);
    this->setMinimumHeight(150);
    this->setMaximumHeight(150);

    QIcon icon(":/icon/logo/sfit.png");
    setWindowIcon(icon);
    setWindowTitle(QStringLiteral("Welcome to SFIT toolkit"));

    pb_logoin =new QPushButton("Login", this);
    pb_close =new QPushButton("Exit", this);

    lb_name = new QLabel("Username ", this);
    lb_paswd =new QLabel("Passwd   ", this);
    le_name = new QLineEdit(this);
    le_passwd = new QLineEdit(this);
    remember = new QCheckBox("remember",this);
    passwd = new QCheckBox("showpass",this);

    lb_ipaddr = new QLabel("IPAddr   ", this);
    le_ipaddr = new QLineEdit(this);

    QHBoxLayout *hbox1 =new QHBoxLayout;
    QHBoxLayout *hbox2 =new QHBoxLayout;
    QHBoxLayout *hbox3 =new QHBoxLayout;
    QHBoxLayout *hbox4 =new QHBoxLayout;
    hbox1->addWidget(lb_name);
    hbox1->addWidget(le_name);
    hbox1->addWidget(remember);

    hbox2->addWidget(lb_paswd);
    hbox2->addWidget(le_passwd);
    hbox2->addWidget(passwd);

    hbox3->addWidget(pb_logoin);
    hbox3->addWidget(pb_close);

    hbox4->addWidget(lb_ipaddr);
    hbox4->addWidget(le_ipaddr);

    QVBoxLayout *vbox = new QVBoxLayout;
    vbox->addLayout(hbox1);
    vbox->addLayout(hbox2);
    vbox->addLayout(hbox4);
    vbox->addLayout(hbox3);

    setLayout(vbox);

   le_passwd->setEchoMode(QLineEdit::Password);
   le_passwd->setMaxLength(16);

    connect(passwd, SIGNAL(toggled(bool)), this, SLOT(pswd()));
}

LoginWindow::~LoginWindow()
{

}

void LoginWindow::pswd()
{
    if(passwd->isChecked()) {
        le_passwd->setEchoMode(QLineEdit::Normal);
    }else {
        le_passwd->setEchoMode(QLineEdit:: Password);
    }
}



