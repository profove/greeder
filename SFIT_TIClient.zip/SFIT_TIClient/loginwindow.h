#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include "global.h"

class LoginWindow : public QWidget
{
    Q_OBJECT

public:
    LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

private:
    QPushButton *pb_logoin, *pb_close;
    QLineEdit *le_name, *le_passwd;
    QCheckBox *remember ,*passwd;
    QLabel *lb_name, *lb_paswd;
    QLabel *lb_ipaddr;
    QLineEdit *le_ipaddr;

    QTcpSocket *m_socket = nullptr;

private slots:
    void pswdMode();
    void loginServer();
    void connected();
};

#endif // LOGINWINDOW_H
