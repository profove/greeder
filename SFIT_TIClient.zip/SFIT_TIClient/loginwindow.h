#ifndef LOGINWINDOW_H
#define LOGINWINDOW_H

#include "global.h"

class LoginWindow : public QWidget
{
    Q_OBJECT

public:
    LoginWindow(QWidget *parent = nullptr);
    ~LoginWindow();

private:
    QPushButton *pb_logoin, *pb_close;
    QLineEdit *le_name, *le_passwd;
    QCheckBox *remember ,*passwd;
    QLabel *lb_name, *lb_paswd;
    QLabel *lb_ipaddr;
    QLineEdit *le_ipaddr;

private slots:
    void pswd();

};

#endif // LOGINWINDOW_H
