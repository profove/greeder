#ifndef GLOBAL_H
#define GLOBAL_H

#include <QLabel>
#include <QLineEdit>
#include <QCheckBox>
#include <QPushButton>
#include <QMainWindow>
#include <QHBoxLayout>

#endif // GLOBAL_H
