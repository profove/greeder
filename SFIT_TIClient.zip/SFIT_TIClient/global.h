#ifndef GLOBAL_H
#define GLOBAL_H

#include <iostream>

#include <QDebug>
#include <QLabel>
#include <QRegExp>
#include <QLineEdit>
#include <QCheckBox>
#include <QTcpSocket>
#include <QMessageBox>
#include <QPushButton>
#include <QMainWindow>
#include <QHBoxLayout>
#include <QHostAddress>
#include <QLocalSocket>
#include <QApplication>
#include <QNetworkProxy>


#define TR(str)     (QString::fromLocal8Bit(str))  //�����������

#endif // GLOBAL_H
